module MusicPlayerApp {
}